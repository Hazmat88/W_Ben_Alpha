// this is here for webpack to expose Swup as window.Swup
import Swup from './src/index.js';
module.exports = Swup;
